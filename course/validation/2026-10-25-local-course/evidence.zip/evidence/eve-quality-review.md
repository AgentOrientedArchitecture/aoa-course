# EVE native acceptance review

Reviewed against the learner-authored instructions copied exactly from the
Session 3 walkthrough. Inputs were synthetic. This review distinguishes a
successful runtime exchange from completion of the agent's required job.

## Initial run: acceptance failed

Evidence: `../checkout/system/agents-eve/workshop/native-results.json` and
`eve-initial-input-requests.json`.

| Input | Native result | Output tokens | Elapsed |
|---|---|---:|---:|
| Rich evaluation: SQL strength, ownership gap | Parked for human input; no final text | 121 | 7.87 s |
| Sparse evaluation: no scores, strengths or gaps | Parked for human input; no final text | 171 | 9.52 s |

Both runs returned `status: waiting`, with a completed model step whose finish
reason was `tool-calls`, followed by `input.requested`. Neither returned the
required JSON object or five questions. These are acceptance failures, not
transport failures. There were no final questions on which to assess semantic
quality or grounding.

The persisted event stream confirms calls to EVE's built-in `ask_question`:

- The rich case asked whether to supply a parsed CV or proceed from the
  evaluation alone. The course contract already makes the CV optional.
- The sparse case asked for fuller evidence rather than inventing weaknesses.
  That caution is sensible, but it does not fulfil the documented requirement
  to return five questions from sparse input.

The model did not hide an answer in a tool call. It asked genuine clarification
questions and EVE correctly parked the session. The initial test probe labelled
the settled turns as completed; the mechanical validator still rejected their
empty replies. The probe now reports this distinction explicitly and captures
sanitised clarification prompts without continuation tokens.

## Supported correction to test

EVE 0.17.1 supplies built-in tools even when no tools are authored. Its bundled
`docs/concepts/default-harness.md`, lines 72–80, documents disabling a default
through a file with the tool's slug. A minimal isolated correction is:

```ts
// agent/tools/ask_question.ts
import { disableTool } from "eve/tools";
export default disableTool();
```

This is an authored capability restriction, not an undocumented `defineAgent`
setting. The docs list `ask_question` and its parking behaviour at line 37.
For a truly tool-free interviewer, the other framework tools also need to be
disabled explicitly. Current comments describing the unmodified agent as
tool-free overstate what the authored filesystem actually controls.

Keep the initial evidence and repeat the same two inputs after restricting
tools. If sparse input still fails, clarify the prompt's conditional behaviour:
the requirement to verify a stated strength cannot apply when no strengths
were supplied. A missing-evidence question must not turn absence of evidence
into a claim that the candidate lacks the skill.

## Semantic review still required after a completed response

Check that the rich response leads with ownership/seniority uncertainty,
tests SQL through a concrete example, and ends with adaptation to the role.
Check that the sparse response asks for missing evidence without inventing
experience, qualifications or weaknesses. Neither response should re-score,
recommend hiring, ask about protected characteristics, or add questions only
in the Markdown rendering.

## Second run: only `ask_question` disabled

Evidence: `../checkout/system/agents-eve/workshop/native-no-ask-results.json`.

The rich input returned valid five-question JSON in 23.50 seconds, using 489
output tokens over two model steps. Its first step requested a framework tool;
removing clarification alone therefore did not establish a tool-free agent.
The final output met the field and word-count limits and reproduced the same
questions in Markdown.

The topics are useful: production ownership, releases, seniority, concrete SQL
performance evidence and a role-ramp question. The wording still needs care.
“A production incident you owned” and “one release you owned” presuppose an
experience for which the input explicitly lacks evidence. A neutral “if you
have an example” qualification would better preserve the hypothesis. The last
question assumes production data operations is the target role; the synthetic
evaluation supplied SQL and ownership evidence but no job description. These
are quality limitations, not invented named employers or fabricated projects.

The sparse input used 494 output tokens over two steps and took 24.94 seconds.
It returned surrounding prose, an empty `questions` array and a request for
more evidence. It failed strict JSON-only and five-question acceptance. Its
refusal to invent findings is appropriate; the prompt needs to distinguish
questions that test supplied claims from neutral questions that elicit missing
evidence. The original instructions demand a stated-strength check even when
the supplied strengths array is empty.

For the next test, restrict all framework tools and clarify that the optional
CV is not a prerequisite, no clarification turn is needed, and sparse input
should yield neutral evidence-gathering questions without assuming candidate
experience or a specific unprovided role. Preserve both prior artifacts.

## Bounded-tool attempt: not accepted as a completed fix

The installed package's runtime recognises ten framework-tool slugs. Contrary
to the bundled documentation table, `agent` and `connection_search` are not
valid `disableTool()` filenames in this build. Those two experimental sentinels
were archived after the runtime rejected them before inference.

With the ten recognised sentinels, `/eve/v1/info` reports `available: []`, all
ten framework tools disabled, and no discovery diagnostics. Compact evidence
is in `eve-model-only-info.json`. That inventory does **not** establish that all
action surfaces are absent.

The first completed case in `native-bounded-results.json` took 88.64 seconds.
It returned mechanically valid five-question JSON, but its event stream shows
an actual `agent` subagent-call. EVE delegated the job to a fresh copy with an
output schema, received its result, and then generated the parent reply.
Disabling the ten framework tools therefore failed to create the intended
single-model, action-free boundary. The parent's reported 853 output tokens
do not by themselves account for the child's inference.

Question quality remained mixed: useful ownership, incident, SQL and role-ramp
topics, but wording still assumed production ownership and scaled decision
authority that the input did not establish.

The sparse case subsequently finished in 86.75 seconds, also after a delegated
action. Its output was strict five-question JSON, with field/word limits and
matching Markdown satisfied. Questions elicited a work example, a trade-off,
a measurable result, learning from difficulty and adaptation to the role.
It did not invent a named employer, domain, qualification or specific past
event, re-score the candidate or recommend hiring. The questions are broadly
usable as requests for missing evidence, though phrases such as a recent
project where the candidate led or contributed significantly still assume
there is such an example. The parent steps reported 900 output tokens; again,
this does not establish total parent-plus-child inference usage.

Both final replies pass the mechanical output checks. Both still fail the
intended action-free execution check because of delegation. The tool inventory
and final JSON shape alone would have missed that distinction.

No canonical course tool restriction or prompt change was adopted. The
proposed walkthrough patch remains an unapproved experimental artifact and
must not be presented as a verified fix. The original and both retry artifacts
are retained for a later investigation.
