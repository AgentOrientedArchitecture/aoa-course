# Local CV rehearsal: independent output review

Reviewed the four original runs against their exact submitted CV/job text,
the saved planner traces and the existing AU instructions. These are a small
teaching fixture set, not a model-quality benchmark. No run was repeated or
edited for this review.

## Original data example: held correctly by the configured gate

Trace `c6cd7dacd3c3`: Qwen supplied a valid task plan. Clef chose
`evaluator-cv-data` with probability **0.6129**, below the unchanged **0.65**
gate. No application AU ran. This is an incomplete data-example walkthrough,
not a parser/evaluator/reporter failure; the downstream missing-output checks
are consequences of that hold.

The earlier small decision probe had probability 0.8271, but used different
emphasis (including “data modelling”), a synthetic use context and a different
candidate order. The live Studio delivered the walkthrough emphasis exactly.
The change cannot be attributed to one factor from these observations. The
general evaluator received 0.3603, exposing overlap between the declarations.
A separately labelled clarified-emphasis run can exercise the application path
without lowering the gate or replacing this baseline.

## Frontend example: functional pass with content issues

Trace `cbec5d854fc3`: Clef chose `evaluator-cv-frontend` at **0.9522**.
The workflow completed in **52.82 seconds**, using a model-proposed plan.
Sam's name, employers, dates, migration from Bootstrap to Tailwind/Radix and
test-coverage figures (18% to 84%) were retained. The `fit` verdict and
`interview` recommendation are consistent. The absence of explicit accessibility
testing evidence is a supported gap.

Content limitations:

- The report introduces “recent senior role” and “senior capacity” concerns.
  The job is Frontend Engineer, not a senior position. The target system has
  about 80 components, but previous ownership of a library of that size is not
  stated as an essential qualification. This framing overstates the job's bar.
- Sam's open-source `react-modal-shell` UI primitive is omitted by the parser.
  The existing parser instructions permit omission of non-role side projects,
  so this is also a contract/instruction limitation. The downstream evaluator
  loses direct evidence for the job's open-source UI “nice to have”.
- Working closely with product designers is a must-have, but the evaluation
  does not flag the lack of explicit evidence. Listing Figma is not proof of
  that working relationship.

## Mismatched CV/job: correct broad outcome, overconfident wording

Trace `1bc4cc6065b0`: Clef again chose the frontend evaluator at **0.9522**;
selection sees the requested assessment, not the CV contents. Qwen proposed a
valid plan, and the workflow completed in **53.69 seconds**. Jordan's parsed
employment history, dates and numeric achievements match the supplied CV.
Scores of 1/1/2/1, verdict `no` and recommendation `pass` consistently identify
the data-engineering/frontend mismatch.

The reporter turns absence of evidence into “zero experience” and “has no
experience”. The CV does not establish a person's complete experience. It
should say the submitted CV supplies no evidence of the required React,
TypeScript and design-system work. The evaluator's broad mismatch is supported;
the stronger factual phrasing is not.

## Conflicting assessment emphasis: abstention expectation failed

Trace `fcce0c25eaea`: the request used the CV workflow with an assessment
emphasis asking for image generation. Clef chose the general evaluator at
**0.7654** and all three CV AUs ran. This did not demonstrate abstention.
The workflow/task purpose still says “score a CV”; the UI field is assessment
emphasis, not unrestricted intent. The conflict needs explicit interpretation
or rejection before execution if that is the intended product behaviour.
Do not claim the earlier synthetic no-fit probe covers this real UI case.

The resulting data report also contains unsupported strengthening:

- It calls all seven years “regulated fintech and e-commerce” experience and
  says that satisfies the regulated-environment requirement. The CV names
  fintech/e-commerce companies but does not evidence seven years of regulated
  work or specific audit responsibilities.
- It upgrades mentoring two juniors and running office hours into a “track
  record of leading teams”. Those activities support mentoring and technical
  leadership, but do not establish the formal small-team delivery leadership
  required in the job.
- “No direct healthcare experience” should be “no healthcare experience
  evidenced in the submitted CV”.

These content issues are separate from the local runtime integration. Typed
responses and high choice probabilities did not prevent them. The outputs
remain suitable for discussing evidence review; they do not justify treating
the assessment as a verified hiring recommendation.

## Separate clarified data run

Trace `b81aa26a0d04`, saved separately under `cv-clarified/`, used:

> This is a senior data-engineering role. Assess production data pipelines, SQL, data modelling, operational reliability and data governance.

The workflow completed in **57.28 seconds** with a valid model-proposed plan.
Clef selected the **general evaluator at 0.7063**, with only 0.2558 for the data
specialist. The threshold remained 0.65. Clarification therefore allowed work
to proceed but did not establish the intended specialist-selection behaviour.
It does not replace the original held result.

The actual general evaluator returned valid scores (5/4/5/2), verdict `fit`
and a consistent `interview` recommendation. The initial helper summary also
reports missing scores/verdict because it looked for the *expected* specialist's
output. Those two failures are an inspection defect, not invalid model output.
The helper has been corrected to review the AU that actually ran while keeping
the wrong-selection check separate. The original evidence file is preserved.

The same source-support issues recur: seven years of regulated work is
asserted without evidence, and the reporter adds “led incident response” when
the CV only lists incident response as a practice. Specific warehouse timing
and schema-incident numbers remain accurate. No further retry was performed.
