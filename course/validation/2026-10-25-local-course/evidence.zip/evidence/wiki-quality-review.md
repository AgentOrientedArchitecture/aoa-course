# Local wiki rehearsal: independent output review

Reviewed all eight original Session 2 runs against the submitted source texts,
stored response evidence and planner traces. Every run completed using a valid
Qwen model-proposed plan; none used a recorded planning fallback. No run was
repeated or altered for this review. Six of the eight bounded automated checks
passed. The two failures and additional manual findings are retained below.

## Promotion and publication

| Input | Observed decision | Winning probability | Publication |
|---|---|---:|---|
| Registry quickstart note | promote | 0.9333 | Four passages stored |
| Unrelated fiction | reject | 0.9222 | Withheld; no write-ingest call |
| Unsupported cost-savings claim | review | 0.7055 | Withheld; no write-ingest call |
| Registry seed note | promote | 0.9335 | Five passages stored, one quote altered |
| Protocol seed note | promote | 0.9362 | Five passages stored |
| Principles seed note | promote | 0.9293 | Five passages stored |

These are the expected high-level classifications. The unsupported claim's
summary retained its lack of evidence. The fiction and unsupported inputs did
not enter the wiki. All promotion decisions came from the native Clef System
One route, and the 0.65 acceptance policy remained unchanged.

## Source fidelity

The quickstart, fiction, unsupported-claim, protocol and principle passage
quotes matched their sources after whitespace normalisation. The registry
seed contains one exception: parser passage `p3` joins the introductory line
and two bullet points into a new comma-separated sentence. Its meaning is
broadly faithful, but it is not a contiguous verbatim source quote. The
promotion code correctly retained the parser's text, then stored the altered
quote. Preservation between AUs therefore did not prove extraction fidelity.

Manual review found further issues outside the automated quote check:

- The protocol note's summary expands AOA as “Agentic Orchestration
  Architecture”. The source does not supply that expansion; the course is
  Agent-Oriented Architecture. This incorrect summary was stored despite five
  correct passage quotes.
- The principles summary calls it “Agentic Unit (AOA) architecture”, confusing
  the AU and AOA terms. Its quoted principles themselves remain accurate.
- The quickstart's generated concept “Probabilistic Contracts” and description
  of a “new type of contract” are model synthesis rather than a concept named
  in the source. They should not be represented as verbatim source terminology.
- The withheld fiction summary says the lantern was stolen; the story says it
  went missing and was borrowed. It was correctly rejected and not published,
  but illustrates that summary fidelity needs its own review.

## Retrieved answers

The supported registry question returned three actual passage IDs and an
answer assembled from those stored passages. Its discussion of observed
behaviour is relevant and traceable. It did not use a new generative answer
call. Some less-direct historical material appears before the most relevant
registry points; citations alone do not establish optimal retrieval ranking.

The absent-evidence question asked for Clef's measured production error rate
in September 2026. The corpus contains no such measurement. Nevertheless,
trace `66a078c2c8bd` returned generic passages about identity, registry metrics
and UDDI, labelled the answer **high confidence**, and supplied an empty gaps
list. It did not fabricate an error-rate number, but it failed to acknowledge
that the retrieved material does not answer the question.

Qwen's query parser did preserve the requested system, production context,
date and metric. The failure occurred after that structured request: the
retrieval/evaluation path did not enforce those constraints.

This is a deterministic retrieval/answer-sufficiency problem, distinct from
Clef's promotion decisions. The evaluator treats a sufficiently high lexical
score as evidence of a direct answer; the reporter can label three citations
high confidence without checking whether they contain the requested fact.
The generated query and full retrieved passages remain in
`wiki/wiki-query-gap.json` for inspection.

## Interpretation

The local stack successfully exercised generation, bounded decisions,
conditional publication, persistent wiki storage, retrieval and cited answer
assembly. It did not establish reliable summary fidelity, exact quote
extraction or refusal on corpus gaps. The data supports a working local
integration with specific quality defects to address, not an all-green course
or a claim that a larger model is necessarily required.
