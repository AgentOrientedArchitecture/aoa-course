import { createOpenAI } from "@ai-sdk/openai";
import { defineAgent } from "eve";

// Endpoint resolution, in order:
//   1. OPENAI_BASE_URL   — any OpenAI-compatible endpoint (SambaNova, NVIDIA
//                          NIM, an MLX server on the host, ...).
//   2. OLLAMA_HOST + /v1 — Ollama's OpenAI-compatible shim.
//   3. localhost Ollama  — only reachable when EVE runs outside Docker;
//                          inside the workshop container Compose always sets
//                          OLLAMA_HOST, so this is a host-dev fallback.
function baseUrl(): string {
  const explicit = process.env.OPENAI_BASE_URL?.trim();
  if (explicit) return explicit;
  const ollama = process.env.OLLAMA_HOST?.trim();
  if (ollama) return `${ollama.replace(/\/$/, "")}/v1`;
  return "http://localhost:11434/v1";
}

const provider = createOpenAI({
  baseURL: baseUrl(),
  // Inside the workshop containers Compose supplies OPENAI_API_KEY from your
  // .env's CEREBRAS_API_KEY (or AOA_OPENAI_API_KEY for other providers), though
  // .env leaves OPENAI_API_KEY itself blank. Local endpoints need no key.
  apiKey: process.env.OPENAI_API_KEY || "not-needed-for-local",
});

export default defineAgent({
  // provider.chat(...) targets /chat/completions, which every
  // OpenAI-compatible endpoint serves. Calling provider(...) directly would
  // select OpenAI's newer Responses API (/responses), which SambaNova,
  // Ollama's shim, and most compatible providers do not implement.
  model: provider.chat(process.env.MODEL || "gpt-oss:120b"),
  modelContextWindowTokens: Number(
    process.env.MODEL_CONTEXT_WINDOW_TOKENS || 128000,
  ),
});
