Partial local-course rehearsal, 25 October 2026. See the adjacent repository README.md.
The evidence is synthetic course input and observed outputs; no provider credentials or EVE private event store are included.
The harness is an experimental source snapshot, archived outside active learner code. It is not a supported course command.
Source baseline: 66c02b0eb197b830b1510dabf95899748aac84cc.
The archived environment helper was updated for the subsequent generic configuration names; stored Compose configurations record the actual earlier run.
EVE source in checkout/ is the last bounded-tool experiment, not the canonical agent. The original is reconstructable from the baseline walkthrough. The proposed patch is unapplied.
Session 3 Directory adoption and Session 4 governance were not run. governance-input.json and its helper are preparation only.
