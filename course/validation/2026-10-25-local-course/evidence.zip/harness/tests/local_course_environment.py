"""Isolated, opt-in full-course rehearsal. Does not read the learner's .env.

Prepare a committed-source copy under an ignored output directory, then render
the real session settings with separate images, loopback ports and bind mounts.
Example: python tests/local_course_environment.py --output .course-data/local-test prepare
Then:    python tests/local_course_environment.py --output .course-data/local-test compose 1 up -d --build
The model server must already be running on host port 18000. No model downloads,
provider credentials or changes to normal course launchers are made here.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
PROJECT = "aoa-local-rehearsal"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--context", default="desktop-linux")
    parser.add_argument("action", choices=("prepare", "compose"))
    parser.add_argument("rest", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to(ROOT / ".course-data"):
        parser.error("Output must be inside this checkout's ignored .course-data directory")
    checkout = output / "checkout"
    # Deliberately omit inherited provider variables and Docker remote overrides.
    env = {k: os.environ[k] for k in ("PATH", "HOME", "TMPDIR") if k in os.environ}
    docker = ["docker", "--context", args.context]
    if args.action == "prepare":
        if checkout.exists():
            parser.error("Checkout already exists; preserve it and choose a new output directory")
        output.mkdir(parents=True, exist_ok=True)
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        blob = subprocess.check_output(["git", "archive", commit], cwd=ROOT)
        checkout.mkdir()
        with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
            archive.extractall(checkout, filter="data")
        assert not (checkout / ".env").exists()
        containers = subprocess.check_output(docker + ["ps", "--format", "{{.ID}} {{.Names}}"], env=env, text=True)
        (output / "pre-existing-containers.txt").write_text(containers)
        manifest = {"commit": commit, "project": PROJECT + "-" + hashlib.sha256(str(output).encode()).hexdigest()[:8], "docker_context": args.context,
                    "checkout": str(checkout), "host_port_offset": 20000,
                    "model_server": "http://host.docker.internal:18000",
                    "generation_model": "Qwen3.8-27B-4bit", "decision_model": "clef-flash-oQ4e"}
        (output / "environment.json").write_text(json.dumps(manifest, indent=2) + "\n")
        print(json.dumps(manifest, indent=2))
        return
    if not checkout.is_dir() or not (output / "environment.json").exists():
        parser.error("Run prepare first")
    manifest = json.loads((output / "environment.json").read_text())
    if manifest["docker_context"] != args.context:
        parser.error("Docker context must match the prepared rehearsal")
    if not args.rest or args.rest[0] not in {"1", "2", "3", "4", "native"}:
        parser.error("compose needs a session (1, 2, 3, 4, native) followed by a Compose command")
    session, *command = args.rest
    project = manifest["project"]
    env.update({
        "PROVIDER": "openai", "MODEL": "Qwen3.8-27B-4bit",
        "LLM_BASE_URL": "http://host.docker.internal:18000/v1",
        "LLM_API_KEY": "local-no-auth", "DECISION_API_KEY": "",
        "DECISION_PROVIDER": "systemone", "DECISION_MODEL": "clef-flash-oQ4e",
        "DECISION_BASE_URL": "http://host.docker.internal:18000",
        "DECISION_ALLOW_UNSCORED": "false", "DECISION_MIN_PROBABILITY": "0.65",
        "MODEL_TIMEOUT_SECONDS": "300", "PLANNER_MODEL_TIMEOUT_SECONDS": "180",
        "PLANNER_INVOKE_TIMEOUT": "420", "PLANNER_REQUEST_TIMEOUT": "600",
        "MODEL_CONTEXT_WINDOW_TOKENS": "32768", "PLANNER_STRATEGY": "hybrid",
        "COURSE_DIRECTORY_DATA_ROOT": str(output / "directory-data"),
        "COURSE_DIRECTORY_UI_PORT": "8891", "COURSE_DIRECTORY_PORT": "8890",
    })
    shell = 'session="$1"; source scripts/compose.sh; "$2" -c '\
        "'import os,json; print(json.dumps({k:v for k,v in os.environ.items() if k.startswith((\"COURSE_\",\"DIRECTORY_\"))}))'"
    exported = subprocess.check_output(["bash", "-c", shell, "rehearsal", "3" if session == "native" else session, sys.executable],
                                       cwd=checkout, env=env, text=True)
    env.update(json.loads(exported))
    profiles = ["session3-lab-native"] if session == "native" else ["session" + session]
    if session == "3": profiles += ["session3-lab-wrapped", "directory"]
    if session == "4": profiles += ["directory"]
    base = docker + ["compose", "--project-name", project, "--env-file", "/dev/null", "-f", str(checkout / "system/docker-compose.yml")]
    for profile in profiles:
        base += ["--profile", profile]
    config = json.loads(subprocess.check_output(base + ["config", "--format", "json"], cwd=checkout, env=env, text=True))
    config["name"] = project
    for service in config["services"].values():
        service.pop("container_name", None)
        service.pop("profiles", None)
        if "build" in service:
            image = service["image"].split("/", 1)[-1].split(":", 1)[0]
            service["image"] = f"{project}/{image}:{manifest['commit'][:12]}"
        for port in service.get("ports", []):
            port["published"] = str(int(port["published"]) + 20000)
            port["host_ip"] = "127.0.0.1"
        for mount in service.get("volumes", []):
            if mount["type"] == "bind":
                source = Path(mount["source"]).resolve()
                if not source.is_relative_to(output):
                    raise RuntimeError(f"Refusing shared bind mount: {source}")
                if not source.exists(): source.mkdir(parents=True)
        values = service.get("environment", {})
        for key, value in values.items():
            if key.endswith("API_KEY") and value not in {"", "local-no-auth", None}:
                raise RuntimeError(f"Unexpected credential in rehearsal: {key}")
            if key in {"LLM_BASE_URL", "DECISION_BASE_URL"} and not value.startswith("http://host.docker.internal:18000"):
                raise RuntimeError(f"Unexpected model endpoint: {key}")
        if "DIRECTORY_DAEMON_SERVER_HTTP_GATEWAY_PUBLIC_URL" in values:
            values["DIRECTORY_DAEMON_SERVER_HTTP_GATEWAY_PUBLIC_URL"] = "http://localhost:28891"
    config["networks"] = {"default": {"name": project + "_default"}}
    for key, value in config.get("volumes", {}).items():
        if value is None: config["volumes"][key] = {"name": project + "_" + key}
        else: value["name"] = project + "_" + key
    generated = output / ("session-" + session + ".compose.json")
    generated.write_text(json.dumps(config, indent=2) + "\n")
    if not command:
        print(generated)
        return
    os.execvpe(docker[0], docker + ["compose", "--project-name", project, "--env-file", "/dev/null", "-f", str(generated)] + command, env)


if __name__ == "__main__":
    main()
