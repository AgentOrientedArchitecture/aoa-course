"""Rehearse CV/wiki workflows against an already isolated local course stack.

This sends real intents and therefore writes runs, inbox files and wiki data in
the target stack. It never starts/stops Docker, reads .env, changes source files,
resets a wiki or configures providers. Default course ports are refused and the
registered generation model is checked before any intent is submitted.

Example (ports are chosen by the caller's isolated stack):
  python tests/local_course_flows.py --session cv --studio-url http://127.0.0.1:28080 \
    --planner-url http://127.0.0.1:27200 --registry-url http://127.0.0.1:27100 \
    --output-dir .course-data/local-rehearsal/cv

The bounded output/quote checks do not establish general assessment quality.
The evidence preserves all outputs and signals for human review.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.parse import urlsplit

import httpx


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_COURSE_PORTS = {7100, 7200, 7250, 8080}


def arguments():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--session", required=True, choices=["cv", "wiki"])
    parser.add_argument("--studio-url", required=True)
    parser.add_argument("--planner-url", required=True)
    parser.add_argument("--registry-url", required=True)
    parser.add_argument("--repo-root", type=Path, default=ROOT)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-generation-model", default="Qwen3.8-27B-4bit")
    parser.add_argument("--timeout", type=float, default=1200)
    parser.add_argument("--cases", help="Optional comma-separated case IDs; default runs the whole session probe")
    parser.add_argument("--assessment-emphasis", help="Explicitly clarified CV emphasis; requires --session cv and exactly one --cases entry")
    args = parser.parse_args()
    for name in ("studio_url", "planner_url", "registry_url"):
        value = getattr(args, name).rstrip("/")
        url = urlsplit(value)
        if (url.scheme != "http" or url.hostname not in {"127.0.0.1", "localhost", "::1"}
                or url.port is None or url.port in DEFAULT_COURSE_PORTS
                or url.username or url.password or url.query or url.fragment or url.path):
            parser.error(f"--{name.replace('_', '-')} must be a loopback server root on an explicit, non-default course port")
        setattr(args, name, value)
    if args.output_dir.exists():
        parser.error("--output-dir must be new; preserve prior evidence")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    if args.assessment_emphasis is not None:
        if args.session != "cv" or not args.cases or len(args.cases.split(",")) != 1 or not args.assessment_emphasis.strip():
            parser.error("--assessment-emphasis requires --session cv, one --cases entry and non-empty text")
    return args


def fixtures(root: Path, session: str):
    def read(relative):
        return (root / "course/sessions" / relative).read_text()

    if session == "cv":
        base = "session-01-cv-fit/"
        data = read(base + "cv-examples/jordan-okafor.txt")
        frontend = read(base + "cv-examples/sam-everett.txt")
        data_job = read(base + "jd-examples/senior-data-engineer-fintech.txt")
        frontend_job = read(base + "jd-examples/frontend-engineer-design-systems.txt")
        data_emphasis = "Assess production data pipelines, SQL, reliability and governance."
        frontend_emphasis = "Assess accessibility, design systems, UI testing and browser performance."
        rows = [
            ("cv-data", data, data_job, data_emphasis, "Jordan Okafor", "evaluator-cv-data"),
            ("cv-frontend", frontend, frontend_job, frontend_emphasis, "Sam Everett", "evaluator-cv-frontend"),
            ("cv-mismatch", data, frontend_job, frontend_emphasis, "Jordan Okafor", "evaluator-cv-frontend"),
            ("cv-outside-scope", data, data_job,
             "Generate a photorealistic product image. No CV assessment, hiring assessment or candidate evaluation is requested.",
             "Jordan Okafor", None),
        ]
        return [{"id": name, "kind": "cv-fit", "expected_name": person, "expected_evaluator": evaluator,
                 "inputs": {"cv_text": cv, "jd_text": jd, "allocation_brief": emphasis,
                            "cv_name": name + "-cv.txt", "jd_name": name + "-jd.txt"}}
                for name, cv, jd, emphasis, person, evaluator in rows]
    base = "session-02-wiki/"
    rows = [
        ("wiki-relevant", read(base + "quickstart-note/agent-registry-lessons.txt"), ["promote"]),
        ("wiki-fiction", read(base + "quickstart-note/not-for-wiki-fairytale.txt"), ["reject"]),
        ("wiki-unsupported", "Someone said the new agent system cut costs dramatically. No figures, method, dates or source were supplied.", ["review", "reject"]),
        ("wiki-seed-registry", read(base + "wiki-seed/03-registries-and-observed-quality.md"), ["promote"]),
        ("wiki-seed-protocols", read(base + "wiki-seed/04-protocol-planes.md"), ["promote"]),
        ("wiki-seed-principles", read(base + "wiki-seed/02-aoa-principles.md"), ["promote"]),
    ]
    return [
        {"id": name, "kind": "knowledge-ingest", "expected_outcomes": expected,
         "inputs": {"note_text": note, "note_name": name + ".txt"}} for name, note, expected in rows
    ] + [
        {"id": "wiki-query", "kind": "knowledge-query",
         "inputs": {"question": "What did the registry lessons note say about observed quality?"}},
        {"id": "wiki-query-gap", "kind": "knowledge-query",
         "inputs": {"question": "What measured error rate did Clef achieve on our production cases in September 2026?"}},
    ]


def write(path: Path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def check(row, name, passed, observed=None):
    row.setdefault("checks", []).append({"name": name, "passed": bool(passed), "observed": observed})


def responses(records):
    return {record["capability"]: record for record in records if record.get("step") == "response"}


def common_checks(row):
    records = row["trace"].get("records", [])
    row["plan_proposals"] = [record for record in records if record.get("step") == "plan-proposal"]
    row["all_response_signals"] = [{"capability": r.get("capability"), "signals": r.get("signals", {})}
                                   for r in records if r.get("step") in {"response", "tool-response"}]
    row["reported_errors"] = [r for r in records if r.get("step") in {"error", "tool-error"}]
    check(row, "trace_present", bool(records))
    check(row, "proposal_source_recorded", bool(row["plan_proposals"]))
    for proposal in row["plan_proposals"]:
        if proposal.get("source") != "llm":
            row.setdefault("observations", []).append({"planning_fallback": proposal.get("fallback_reason"),
                                                       "detail": proposal.get("fallback_detail"), "source": proposal.get("source")})
    # The fallback is valid course behaviour, but must not be described as model planning.
    row["model_proposed_plan"] = bool(row["plan_proposals"]) and all(r.get("source") == "llm" for r in row["plan_proposals"])
    return records, responses(records)


def inspect_cv(row, case):
    records, by_capability = common_checks(row)
    if case["expected_evaluator"] is None:
        held = [r for r in records if r.get("step") == "allocation-held"]
        invoked = [r.get("capability") for r in records if r.get("step") == "invoke"]
        check(row, "outside_scope_held_before_application", bool(held) and not invoked,
              {"holds": held, "invocations": invoked})
        row.setdefault("observations", []).append("The fixed CV workflow still supplies the task purpose; the out-of-scope instruction is assessment emphasis only. This is a semantic abstention probe, not an image-generation workflow.")
        return
    check(row, "completed", row.get("response", {}).get("status") == "done", row.get("response", {}).get("status"))
    selected = [r.get("accepted_choice") for r in records if r.get("step") == "allocation-accepted"
                and str(r.get("accepted_choice", "")).startswith("evaluator-cv")]
    check(row, "expected_evaluator_selected", selected == [case["expected_evaluator"]], selected)
    decisions = [r.get("decision", {}) for r in records if r.get("step") == "allocation" and r.get("model_called")]
    check(row, "native_clef_allocation_observed", bool(decisions) and all(d.get("provider") == "systemone" and "clef" in str(d.get("model", "")).lower() for d in decisions), decisions)
    parser = by_capability.get("parser-cv", {}).get("outputs", {}).get("parsed", {})
    check(row, "candidate_name_preserved", parser.get("name") == case["expected_name"], parser.get("name"))
    check(row, "parser_contract_fields", all(key in parser for key in ("name", "email", "summary", "skills", "experience", "education")))
    observed_evaluator = selected[0] if len(selected) == 1 else case["expected_evaluator"]
    evaluation = by_capability.get(observed_evaluator, {}).get("outputs", {})
    scores = evaluation.get("scores", {})
    required = {"skills_match", "experience_relevance", "seniority_match", "domain_familiarity"}
    check(row, "scores_have_required_fields_and_range", isinstance(scores, dict) and required <= scores.keys()
          and all(isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 5 for v in scores.values()), scores)
    check(row, "valid_verdict", evaluation.get("verdict") in {"strong", "fit", "weak", "no"}, evaluation.get("verdict"))
    check(row, "strong_verdict_not_inconsistent_with_low_score", evaluation.get("verdict") != "strong" or all(v >= 3 for v in scores.values() if isinstance(v, (int, float))))
    final = row.get("response", {}).get("outputs", {})
    check(row, "report_has_recommendation_and_markdown", final.get("recommendation") in {"interview", "hold", "pass"}
          and bool(final.get("report_markdown")), final.get("recommendation"))
    check(row, "document_tool_observed", any(r.get("step") == "tool-invoke" and r.get("capability") == "tool-document-text" for r in records))
    check(row, "application_output_shapes_valid", all(r.get("signals", {}).get("valid_output_shape") is True for r in by_capability.values()) and len(by_capability) == 3)
    row["quality_review"] = {"observed_evaluator": observed_evaluator, "parsed_cv": parser, "evaluation": evaluation, "report": final,
                             "scope": "Checks cover named fields, ranges and a few consistency conditions. Human review of source support remains necessary."}
    if case["id"] == "cv-mismatch":
        check(row, "mismatch_verdict_is_weak_or_no", evaluation.get("verdict") in {"weak", "no"}, evaluation.get("verdict"))


def inspect_wiki(row, case):
    records, by_capability = common_checks(row)
    check(row, "completed", row.get("response", {}).get("status") == "done", row.get("response", {}).get("status"))
    if case["kind"] == "knowledge-ingest":
        parsed = by_capability.get("parser-notes", {}).get("outputs", {}).get("parsed_note", {})
        passages = parsed.get("passages", [])
        normalise = lambda value: " ".join(value.split())
        source = normalise(case["inputs"]["note_text"])
        fidelity = [{"passage_id": p.get("passage_id"), "quote": p.get("quote"),
                     "verbatim_ignoring_whitespace": isinstance(p.get("quote"), str) and bool(p["quote"].strip()) and normalise(p["quote"]) in source}
                    for p in passages if isinstance(p, dict)]
        row["source_quote_checks"] = fidelity
        check(row, "every_extracted_quote_matches_source", all(p["verbatim_ignoring_whitespace"] for p in fidelity), fidelity)
        promotion = by_capability.get("evaluator-promote", {}).get("outputs", {}).get("promotion", {})
        outcome = promotion.get("decision_outcome")
        check(row, "expected_promotion_outcome", outcome in case["expected_outcomes"], outcome)
        evidence = promotion.get("decision_evidence", {})
        check(row, "native_clef_decision_observed", evidence.get("provider") == "systemone" and "clef" in str(evidence.get("model", "")).lower(), evidence)
        stored = row.get("response", {}).get("outputs", {}).get("stored", {})
        write_calls = [r for r in records if r.get("step") == "tool-invoke" and r.get("capability") == "tool-wiki-store"
                       and r.get("operation") == "write_ingest"]
        if outcome in {"reject", "review"}:
            check(row, "withheld_content_not_stored", promotion.get("promote") is False and stored.get("skipped") is True and not write_calls,
                  {"stored": stored, "write_calls": write_calls})
        elif outcome == "promote":
            check(row, "promoted_content_stored", promotion.get("promote") is True and bool(stored.get("document_id")) and stored.get("passage_count", 0) > 0, stored)
            before = {p.get("passage_id"): p.get("quote") for p in passages if isinstance(p, dict)}
            check(row, "promotion_keeps_parser_quotes", all(before.get(p.get("passage_id")) == p.get("quote") for p in promotion.get("promoted_passages", [])))
        row["promotion"] = promotion
    else:
        retrieved = by_capability.get("evaluator-wiki-query", {}).get("outputs", {}).get("parsed_note", {}).get("passages", [])
        final = row.get("response", {}).get("outputs", {})
        ids = {p.get("passage_id") for p in retrieved if isinstance(p, dict)}
        citations = final.get("citations", [])
        check(row, "citations_resolve_to_retrieved_passages", isinstance(citations, list) and all(pid in ids for pid in citations), citations)
        check(row, "wiki_search_observed", any(r.get("step") == "tool-invoke" and r.get("capability") == "tool-wiki-store" for r in records))
        if case["id"] == "wiki-query":
            check(row, "grounded_answer_has_citations", bool(citations), final)
        else:
            check(row, "unknown_question_reports_gap", bool(final.get("gaps")) or not citations, final)
        row["retrieved_passages"] = retrieved
        row["answer"] = final


def main():
    args = arguments()
    cases = fixtures(args.repo_root, args.session)
    if args.cases:
        wanted = set(args.cases.split(","))
        unknown = wanted - {c["id"] for c in cases}
        if unknown:
            raise SystemExit("Unknown case IDs: " + ", ".join(sorted(unknown)))
        cases = [c for c in cases if c["id"] in wanted]
    if args.assessment_emphasis is not None:
        cases[0]["original_assessment_emphasis"] = cases[0]["inputs"]["allocation_brief"]
        cases[0]["inputs"]["allocation_brief"] = args.assessment_emphasis
    with httpx.Client(timeout=args.timeout, trust_env=False) as client:
        registry_response = client.get(args.registry_url + "/list")
        registry_response.raise_for_status()
        registry = registry_response.json()
        cards = registry.get("capabilities", [])
        parser_id = "parser-cv" if args.session == "cv" else "parser-notes"
        parser_card = next((c for c in cards if c.get("id") == parser_id), {})
        if parser_card.get("provenance", {}).get("model") != args.expected_generation_model:
            raise SystemExit("Refusing intents: target parser card does not advertise the expected local generation model")
        health = client.get(args.planner_url + "/healthz")
        health.raise_for_status()
        args.output_dir.mkdir(parents=True)
        report = {"started_at": datetime.now(timezone.utc).isoformat(), "session": args.session,
                  "endpoints": {"studio": args.studio_url, "planner": args.planner_url, "registry": args.registry_url},
                  "expected_generation_model": args.expected_generation_model, "planner_health": health.json(),
                  "scope": "Actual Studio intents and full application workflows; bounded output checks, not general model quality or browser interaction testing.", "cases": []}
        write(args.output_dir / "registry-before.json", registry)
        for case in cases:
            payload = {"kind": case["kind"], "inputs": case["inputs"]}
            row = {"case_id": case["id"], "request": payload,
                   "request_sha256": hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()}
            if "original_assessment_emphasis" in case:
                row["clarification"] = {"original_assessment_emphasis": case["original_assessment_emphasis"],
                                        "tested_assessment_emphasis": args.assessment_emphasis,
                                        "scope": "Explicitly changed input for a separate rehearsal; does not replace the original walkthrough result."}
            before = set(client.get(args.planner_url + "/traces").json().get("traces", []))
            started = time.perf_counter()
            try:
                response = client.post(args.studio_url + "/api/intent", json=payload)
                row["http_status"] = response.status_code
                row["response"] = response.json()
            except httpx.HTTPError as exc:
                row["request_error_type"] = type(exc).__name__
            row["elapsed_seconds"] = time.perf_counter() - started
            trace_id = row.get("response", {}).get("trace_id")
            if not trace_id:
                after = set(client.get(args.planner_url + "/traces").json().get("traces", []))
                new_traces = sorted(after - before)
                row["new_trace_ids"] = new_traces
                trace_id = new_traces[0] if len(new_traces) == 1 else None
            row["trace"] = client.get(args.planner_url + "/traces/" + trace_id).json() if trace_id else {"records": []}
            if trace_id:
                row["saved_run"] = client.get(args.planner_url + "/runs/" + trace_id).json()
            # Preserve actual evidence even if an unexpected model shape breaks
            # an inspection check. An analyser error is not a successful run.
            write(args.output_dir / (case["id"] + ".json"), row)
            try:
                if args.session == "cv":
                    inspect_cv(row, case)
                else:
                    inspect_wiki(row, case)
            except (KeyError, TypeError, AttributeError, ValueError) as exc:
                row["inspection_error"] = {"type": type(exc).__name__, "detail": str(exc)}
                row.setdefault("model_proposed_plan", False)
                check(row, "inspection_completed", False)
            row["all_checks_pass"] = all(item["passed"] for item in row["checks"])
            report["cases"].append({"case_id": case["id"], "all_checks_pass": row["all_checks_pass"],
                                    "model_proposed_plan": row["model_proposed_plan"], "elapsed_seconds": row["elapsed_seconds"],
                                    "failed_checks": [c["name"] for c in row["checks"] if not c["passed"]], "trace_id": trace_id})
            write(args.output_dir / (case["id"] + ".json"), row)
            write(args.output_dir / "summary.json", report)
            print(json.dumps(report["cases"][-1]), flush=True)
            if row.get("request_error_type"):
                report["stopped_after_transport_error"] = True
                break  # Do not queue more work behind a possibly still-running intent.
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        report["all_checks_pass"] = len(report["cases"]) == len(cases) and all(c["all_checks_pass"] for c in report["cases"])
        write(args.output_dir / "summary.json", report)
        return 0 if report["all_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
