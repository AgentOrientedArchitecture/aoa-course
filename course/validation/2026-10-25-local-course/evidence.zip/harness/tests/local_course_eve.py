"""Inspect captured EVE results without calling a model or changing the course.

Native acceptance uses raw final text, so the adoption bridge cannot hide JSON
fences or surrounding prose. Mechanical checks are separate from the judgement
of whether a question is useful and supported by the supplied evidence.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def _no_constant(value):
    raise ValueError(f"Non-JSON number {value}")


def validate_questions(value):
    """Validate raw JSON text or already parsed output; never repair its shape."""
    errors = []
    if isinstance(value, str):
        try:
            value = json.loads(value, object_pairs_hook=_unique_object, parse_constant=_no_constant)
        except (ValueError, TypeError):
            return {"mechanical_pass": False, "errors": ["Final text is not one strict JSON value."], "word_counts": []}
    if not isinstance(value, dict) or set(value) != {"questions", "report_markdown"}:
        return {"mechanical_pass": False, "errors": ["Output must contain exactly questions and report_markdown."], "word_counts": []}
    questions = value["questions"]
    if not isinstance(questions, list) or len(questions) != 5:
        errors.append("questions must contain exactly five objects.")
        questions = questions if isinstance(questions, list) else []
    report = value["report_markdown"]
    if not isinstance(report, str) or not report.strip():
        errors.append("report_markdown must be a non-empty string.")
    normalised_report = " ".join(report.split()) if isinstance(report, str) else ""
    counts = []
    for number, question in enumerate(questions, 1):
        if not isinstance(question, dict) or set(question) != {"area", "question", "why"}:
            errors.append(f"Question {number} must contain exactly area, question and why.")
            continue
        row = {"number": number}
        for key, limit in (("area", 6), ("question", 35), ("why", 15)):
            text = question[key]
            if not isinstance(text, str) or not text.strip():
                errors.append(f"Question {number} {key} must be a non-empty string.")
                continue
            row[key] = len(text.split())
            if row[key] > limit:
                errors.append(f"Question {number} {key} exceeds {limit} words.")
        if isinstance(question["question"], str) and " ".join(question["question"].split()) not in normalised_report:
            errors.append(f"Question {number} is not reproduced in report_markdown.")
        counts.append(row)
    return {"mechanical_pass": not errors, "errors": errors, "word_counts": counts}


def validate_adopted_trace(records):
    """Check that Directory binding, EVE invocation and received input are visible."""
    discovery = [row for row in records if row.get("step") == "directory-discovery"]
    bindings = [binding for row in discovery for binding in row.get("accepted", [])
                if binding.get("capability") == "interviewer-questions"]
    invokes = [row for row in records if row.get("step") == "invoke" and row.get("capability") == "interviewer-questions"]
    boundaries = [row for row in records if row.get("capability") == "interviewer-questions"]
    starts = [row for row in boundaries if row.get("step") == "au-start"]
    finishes = [row for row in boundaries if row.get("step") == "au-finish"]
    checks = {
        "retrieved_directory_binding": any(row.get("source") == "agntcy-directory" and row.get("cid") and row.get("local_adoption_checked") is True for row in bindings),
        "no_missing_current_publications": bool(discovery) and all(not row.get("missing_current_publication") for row in discovery),
        "eve_invoked_once": len(invokes) == 1,
        "received_evaluation": len(invokes) == 1 and isinstance(invokes[0].get("inputs", {}).get("evaluation"), dict),
        "native_boundary_started_and_finished": len(starts) == 1 and len(finishes) == 1,
        "no_eve_error": not any(row.get("step") == "au-error" for row in boundaries),
    }
    responses = [row for row in boundaries if row.get("step") == "response"]
    questions = validate_questions(responses[-1].get("outputs")) if responses else {"mechanical_pass": False, "errors": ["No interviewer response recorded."]}
    return {"pass": all(checks.values()) and questions["mechanical_pass"], "checks": checks, "questions": questions,
            "content_ids": [row.get("cid") for row in bindings]}


def validate_native(report):
    results = []
    for case in report.get("cases", []):
        check = validate_questions(case.get("raw_text", ""))
        output_tokens = [step.get("usage", {}).get("outputTokens") for step in case.get("steps", [])
                         if isinstance(step.get("usage"), dict)]
        known_tokens = bool(output_tokens) and all(isinstance(count, (int, float)) for count in output_tokens)
        token_count = sum(output_tokens) if known_tokens else None
        if token_count is not None and token_count > 1200:
            check["errors"].append("Native turn exceeded the 1200 output-token limit.")
            check["mechanical_pass"] = False
        if not case.get("native_turn_completed"):
            check["errors"].append("Native turn did not complete successfully.")
            check["mechanical_pass"] = False
        input_requests = case.get("event_types", []).count("input.requested")
        if input_requests:
            check["errors"].append("Native turn parked for human input instead of completing the bounded response.")
            check["mechanical_pass"] = False
        results.append({"case_id": case.get("id"), **check, "output_tokens": token_count,
                        "token_limit_verified": token_count is not None and token_count <= 1200,
                        "action_requests": case.get("event_types", []).count("actions.requested"),
                        "input_requests": input_requests})
    return {"mechanical_pass": bool(results) and all(row["mechanical_pass"] for row in results), "cases": results,
            "manual_review_required": [
                "Lead with the supplied gap or weakest score, and verify supplied strengths as hypotheses.",
                "Use grounded evidence-seeking questions without invented candidate details, including sparse input.",
                "End with adaptation to the role; do not re-score or make a hiring recommendation.",
                "Markdown contains only the same five questions, without repeated rationale or extra questions.",
            ]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=("native", "trace", "questions"))
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    value = json.loads(args.input.read_text())
    if args.kind == "native":
        result = validate_native(value)
    elif args.kind == "trace":
        result = validate_adopted_trace(value.get("records", value) if isinstance(value, dict) else value)
    else:
        result = validate_questions(value)
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        with args.output.open("x") as stream:
            stream.write(rendered)
    print(rendered, end="")
    raise SystemExit(0 if result.get("pass", result.get("mechanical_pass", False)) else 1)
