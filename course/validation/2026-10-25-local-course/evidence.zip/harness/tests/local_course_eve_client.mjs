// Run inside the isolated workshop, where the pinned eve/client is installed.
// Usage: node local_course_eve_client.mjs http://127.0.0.1:3000 /workshop/native-results.json
// No AOA bridge: retain raw final text for strict native acceptance checks.
import fs from "node:fs";
import { Client } from "eve/client";

const [host, output] = process.argv.slice(2);
if (!host || !output || fs.existsSync(output)) {
  throw new Error("Supply an EVE origin and a new evidence file path.");
}
const url = new URL(host);
if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.pathname !== "/") {
  throw new Error("Use an HTTP origin without credentials or a path.");
}
const client = new Client({ host, maxReconnectAttempts: 1 });
const fixtures = [
  {
    id: "rich-evaluation",
    evaluation: {
      scores: { seniority_match: 2, sql_depth: 4 }, verdict: "fit",
      strengths: ["Strong SQL"], gaps: ["No production ownership evidence"],
      rationale: "SQL evidence is strong; operational ownership is unclear.",
    },
  },
  {
    id: "sparse-evaluation",
    evaluation: {
      scores: {}, verdict: "uncertain", strengths: [], gaps: [],
      rationale: "Insufficient supplied evidence.",
    },
  },
];
const report = {
  schema_version: 1, started_at: new Date().toISOString(), host,
  scope: "Two synthetic native EVE turns through the pinned SDK; no adoption bridge or structured-output override.",
  cases: [],
};
fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
const save = () => fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
for (const fixture of fixtures) {
  const row = { ...fixture, message: `Design interview questions from this evaluation:\n${JSON.stringify(fixture.evaluation)}` };
  const started = performance.now();
  try {
    const response = await client.session().send({ message: row.message, signal: AbortSignal.timeout(300000) });
    const result = await response.result();
    row.session_id = result.sessionId;
    row.status = result.status;
    row.raw_text = result.message ?? "";
    row.event_types = result.events.map((event) => event.type);
    // Do not persist reasoning text, transport headers or continuation tokens.
    row.steps = result.events.filter((event) => event.type === "step.completed").map((event) => ({
      finish_reason: event.data?.finishReason,
      usage: event.data?.usage,
    }));
    row.input_requests = result.events.filter((event) => event.type === "input.requested").flatMap((event) =>
      (event.data?.requests ?? []).map((request) => ({
        tool_name: request.action?.toolName,
        prompt: request.prompt,
        options: request.options?.map((option) => ({ id: option.id, label: option.label })),
      })),
    );
    row.failed_events = result.events.filter((event) => ["step.failed", "turn.failed", "session.failed"].includes(event.type)).map((event) => ({
      type: event.type, code: event.data?.code,
    }));
    row.native_turn_settled = ["waiting", "completed"].includes(result.status) && !row.failed_events.length;
    row.native_turn_completed = row.native_turn_settled && !row.input_requests.length && Boolean(row.raw_text.trim());
  } catch (error) {
    row.error = { name: error.name, status: error.status ?? null };
    row.native_turn_completed = false;
  }
  row.elapsed_seconds = (performance.now() - started) / 1000;
  report.cases.push(row);
  save();
  console.log(`${row.native_turn_completed ? "COMPLETED" : "FAILED"}: ${row.id} (${row.elapsed_seconds.toFixed(2)}s)`);
}
report.finished_at = new Date().toISOString();
save();
if (report.cases.some((row) => !row.native_turn_completed)) process.exitCode = 1;
