"""Stage the hosted-provider Session 4 rehearsal in an isolated course copy.

This helper makes HTTP requests only. It neither edits capability cards nor
starts/stops containers. The operator seeds the isolated wiki, updates the
selected copied card and republishes it between ``before`` and ``hold``, then
restarts only the isolated planner between ``hold`` and ``review``. The optional
``missing-evidence`` stage assumes the operator has safely withheld required
wiki evidence in the isolated copy, after the normal stages are complete.

The card and flow evidence stages are deterministic; the CV runs use the
configured live generation and decision providers. Synthetic course inputs
only: the evidence files preserve complete requests, outputs and traces.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, ProxyHandler


CONSTRAINT = "Every verdict is a draft and must be approved by a human reviewer before it informs candidate screening, interview, or employment action."


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(plan_digest, outputs):
    canonical = json.dumps({"plan_digest": plan_digest, "outputs": outputs}, sort_keys=True,
                           separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]


class Rehearsal:
    def __init__(self, args):
        self.args = args
        self.path = args.output_dir / f"governance-{args.stage}.json"
        if self.path.exists():
            raise ValueError(f"Preserving existing evidence: {self.path}")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.opener = build_opener(ProxyHandler({}))
        self.report = {"stage": args.stage, "started_at": now(), "planner_url": args.planner_url,
                       "expected_evaluator": args.expected_evaluator,
                       "scope": "Isolated Session 4 HTTP rehearsal; card evidence and flow audit are deterministic, CV uses configured live models.",
                       "limits": ["Automated review requests exercise protocol integrity, not effective human oversight or legal compliance.",
                                  "The operator records the actual planner restart separately; this helper checks its persisted effects.",
                                  "A successful CV output shape does not prove assessment quality."],
                       "checks": [], "exchanges": [], "runs": {}}
        self.cv_intent = json.loads(args.cv_intent.read_text())
        if self.cv_intent.get("kind") != "cv-fit":
            raise ValueError("--cv-intent must contain kind=cv-fit and synthetic input paths")
        self.report["cv_intent"] = self.cv_intent
        self.save()

    def save(self):
        self.path.write_text(json.dumps(self.report, indent=2, ensure_ascii=False) + "\n")

    def check(self, name, ok, detail=None):
        self.report["checks"].append({"name": name, "passed": bool(ok), "detail": detail})
        self.save()
        if not ok:
            raise AssertionError(name)

    def request(self, method, path, payload=None, expected=200):
        start = time.monotonic()
        request = Request(self.args.planner_url + path,
                          data=json.dumps(payload).encode() if payload is not None else None,
                          headers={"Content-Type": "application/json"}, method=method)
        try:
            with self.opener.open(request, timeout=self.args.timeout) as response:
                status, body = response.status, response.read()
        except HTTPError as exc:
            status, body = exc.code, exc.read()
        try:
            decoded = json.loads(body)
        except json.JSONDecodeError:
            decoded = {"error": "Response was not JSON", "response_bytes": len(body)}
        self.report["exchanges"].append({"method": method, "path": path, "request": payload,
                                         "status": status, "elapsed_seconds": time.monotonic() - start,
                                         "response": decoded})
        self.save()
        self.check(f"{method} {path} returns {expected}", status == expected, status)
        return decoded

    def run(self, label, intent):
        print(f"Running {label}: {intent['kind']}", flush=True)
        response = self.request("POST", "/intent", intent)
        trace_id = response["trace_id"]
        snapshot = self.request("GET", f"/runs/{trace_id}")
        trace = self.request("GET", f"/traces/{trace_id}")["records"]
        result = {"response": response, "snapshot": snapshot, "records": trace}
        self.report["runs"][label] = result
        self.save()
        self.check(f"{label}: AGNTCY supplies current discovery", any(
            row.get("step") == "directory-discovery" and not row.get("missing_current_publication")
            for row in trace))
        return result

    @staticmethod
    def evaluator(run):
        return next(row["capability"] for row in run["snapshot"]["plan"]
                    if row["capability"].startswith("evaluator-cv"))

    @staticmethod
    def output(run, capability):
        return next(row["outputs"] for row in run["records"]
                    if row.get("step") == "response" and row.get("capability") == capability)

    def evidence(self, run, selected, colour):
        self.check("Card evidence workflow completed", run["snapshot"]["status"] == "done")
        findings = self.output(run, "evaluator-agent-evidence")["findings"]
        finding = next(row for row in findings if row.get("capability_id") == selected and row.get("article") == "Art 14")
        self.check(f"{selected}: Article 14 declaration is {colour}", finding["severity"] == colour, finding)
        citation = finding.get("regulation_citation") or {}
        self.check("Article 14 has passage ID, source and exact quote", all(citation.get(key) for key in ("passage_id", "source_path", "quote")))
        self.check("Card evidence visibly invokes wiki retrieval", any(
            row.get("step") == "tool-invoke" and row.get("capability") == "tool-wiki-store"
            and row.get("parent_capability") == "evaluator-agent-evidence" for row in run["records"]))

    def held(self, run):
        snapshot = run["snapshot"]
        self.check("CV result is draft-held", snapshot["status"] == "draft-held", snapshot["status"])
        self.check("Draft digest matches its exact payload", snapshot["result_digest"] == digest(snapshot["plan_digest"], snapshot["draft_outputs"]))
        self.check("Draft contains generated CV report", bool(snapshot["draft_outputs"].get("report_markdown")))
        self.check("Held draft has no released output", not snapshot["outputs"])
        steps = [row.get("step") for row in run["records"]]
        self.check("Draft and hold follow application completion", "result-draft" in steps and "result-hold" in steps
                   and max(i for i, step in enumerate(steps) if step == "response") < steps.index("result-draft") < steps.index("result-hold"))
        self.check("Held draft has no release event", "result-release" not in steps)
        self.check("Governance permits execution only with the selected declaration", snapshot["governance"].get("decision") == "proceed"
                   and snapshot["governance"].get("card_eligibility", {}).get("eligible") is True)
        self.check("Governance precedes application invocation", steps.index("plan-governance") < steps.index("invoke"))
        citations = snapshot["governance"].get("knowledge_evidence", {}).get("citations", {})
        self.check("Eligibility cites both required wiki passages", all(citations.get(name, {}).get("passage_id") for name in ("Annex III", "Art 14")))
        responses = [row for row in run["records"] if row.get("step") == "response"]
        self.check("All three application AUs returned valid output shapes", len(responses) == 3
                   and all(row.get("signals", {}).get("valid_output_shape") is True for row in responses))

    def before(self):
        health = self.request("GET", "/healthz")
        self.check("Session 4 uses persistent cases and fixed task plans",
                   health.get("durable_cases") is True and health.get("planner_strategy") == "deterministic")
        cards = self.run("cards_before", {"kind": "agent-card-check", "inputs": {"estate_root": "/data/estate"}})
        cv = self.run("cv_rejected", self.cv_intent)
        selected = self.evaluator(cv)
        self.report["selected_evaluator"] = selected
        self.report["next_constraint"] = CONSTRAINT
        self.save()
        self.check("Requested general evaluator was selected", selected == self.args.expected_evaluator, selected)
        self.evidence(cards, selected, "red")
        self.check("Missing declaration rejects governance", cv["snapshot"]["status"] == "rejected")
        eligibility = cv["snapshot"]["governance"].get("card_eligibility", {})
        self.check("Rejection identifies the selected card's missing declaration", eligibility.get("eligible") is False
                   and eligibility.get("capability_id") == selected and not eligibility.get("matched_constraint"), eligibility)
        citations = cv["snapshot"]["governance"].get("knowledge_evidence", {}).get("citations", {})
        self.check("Seeded required evidence was available during rejection", all(citations.get(name, {}).get("passage_id") for name in ("Annex III", "Art 14")))
        self.check("Rejection precedes every application lookup/invoke", not any(row.get("step") in {"lookup", "invoke"} for row in cv["records"]))
        self.check("Rejected plan has no assessment draft", not cv["snapshot"]["draft_outputs"])

    def hold(self):
        previous = self.previous("before")
        selected = previous["selected_evaluator"]
        cards = self.run("cards_after", {"kind": "agent-card-check", "inputs": {"estate_root": "/data/estate"}})
        self.evidence(cards, selected, "green")
        cv = self.run("cv_held", self.cv_intent)
        self.check("CV selects the evaluator whose declaration changed", self.evaluator(cv) == selected)
        self.held(cv)
        self.report["selected_evaluator"] = selected
        self.report["previous_trace_id"] = previous["runs"]["cv_rejected"]["snapshot"]["trace_id"]

    def previous(self, stage):
        path = self.args.previous or self.args.output_dir / f"governance-{stage}.json"
        prior = json.loads(path.read_text())
        self.check(f"Previous {stage} stage completed", prior.get("stage") == stage and prior.get("passed") is True)
        self.check("Previous stage belongs to same isolated planner", prior["planner_url"] == self.args.planner_url)
        self.check("CV inputs are unchanged between stages", prior["cv_intent"] == self.cv_intent)
        self.check("Expected evaluator is unchanged between stages", prior.get("expected_evaluator") == self.args.expected_evaluator)
        return prior

    def review(self):
        prior = self.previous("hold")
        before = prior["runs"]["cv_held"]["snapshot"]
        trace_id = before["trace_id"]
        recovered = self.request("GET", f"/runs/{trace_id}")
        self.check("Restart restores the exact held snapshot", recovered == before)
        trace_before = self.request("GET", f"/traces/{trace_id}")["records"]
        self.check("Restart performs no second AU invocation", trace_before == prior["runs"]["cv_held"]["records"])
        payload = {"decision": "approve", "result_digest": before["result_digest"],
                   "review_notes": "Synthetic course rehearsal: checked exact draft digest and protocol behaviour; not a real employment decision or human-quality evaluation."}
        endpoint = f"/runs/{trace_id}/review"
        self.request("POST", endpoint, {**payload, "review_notes": ""}, expected=400)
        self.request("POST", endpoint, {**payload, "result_digest": "wrong-digest"}, expected=409)
        unchanged = self.request("GET", f"/runs/{trace_id}")
        self.check("Invalid review requests preserve the held draft", unchanged == recovered)
        released = self.request("POST", endpoint, payload)
        self.check("Approval releases the exact frozen draft", released["status"] == "released" and released["outputs"] == before["draft_outputs"])
        first_events = self.request("GET", f"/traces/{trace_id}")["records"]
        repeated = self.request("POST", endpoint, payload)
        repeated_events = self.request("GET", f"/traces/{trace_id}")["records"]
        self.check("Identical review is idempotent", repeated == released and first_events == repeated_events)
        self.check("Exactly one review and release are recorded", sum(r.get("step") == "result-review" for r in first_events) == 1
                   and sum(r.get("step") == "result-release" for r in first_events) == 1)
        self.request("POST", endpoint, {**payload, "decision": "reject"}, expected=409)
        second = self.run("cv_for_quarantine", self.cv_intent)
        self.check("Separate quarantine run uses the same declared evaluator", self.evaluator(second) == prior["selected_evaluator"])
        self.held(second)
        second_id = second["snapshot"]["trace_id"]
        reject = {"decision": "reject", "result_digest": second["snapshot"]["result_digest"],
                  "review_notes": "Synthetic course rehearsal: deliberately quarantine this separate exact draft to test the rejection path."}
        quarantined = self.request("POST", f"/runs/{second_id}/review", reject)
        self.check("Rejection quarantines without releasing the assessment", quarantined["status"] == "quarantined"
                   and quarantined["outputs"] == {"status": "quarantined", "result_digest": reject["result_digest"]})
        quarantine_events = self.request("GET", f"/traces/{second_id}")["records"]
        self.check("Quarantine trace has no release event", not any(r.get("step") == "result-release" for r in quarantine_events))
        audit = self.run("flow_audit", {"kind": "flow-audit", "inputs": {"estate_root": "/data/estate", "include_legacy": False}})
        self.check("Flow audit workflow completed", audit["snapshot"]["status"] == "done")
        findings = self.output(audit, "evaluator-flow-evidence")["plan_findings"]
        targets = {prior["previous_trace_id"], trace_id, second_id}
        for target in targets:
            finding = next((row for row in findings if row.get("trace_id") == target), {})
            self.check(f"Audit explains controlled outcome for {target}", finding.get("severity") == "green", finding)
            citation = finding.get("regulation_citation") or {}
            self.check(f"Audit cites Article 14 for {target}", all(citation.get(key) for key in ("passage_id", "source_path", "quote")))
        self.report["outcomes"] = {"released": trace_id, "quarantined": second_id, "rejected_before_execution": prior["previous_trace_id"]}

    def missing_evidence(self):
        self.previous("review")
        run = self.run("cv_without_required_evidence", self.cv_intent)
        governance = run["snapshot"]["governance"]
        self.check("Evaluator declaration is still eligible", governance.get("card_eligibility", {}).get("eligible") is True)
        citations = governance.get("knowledge_evidence", {}).get("citations", {})
        self.check("At least one required wiki citation is absent", any(not citations.get(name) for name in ("Annex III", "Art 14")), citations)
        self.check("Missing wiki evidence fails closed", run["snapshot"]["status"] == "rejected" and governance.get("decision") == "reject")
        self.check("Missing evidence prevents every application lookup/invoke", not any(row.get("step") in {"lookup", "invoke"} for row in run["records"]))
        self.check("Missing evidence produces no CV draft", not run["snapshot"]["draft_outputs"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("before", "hold", "review", "missing-evidence"))
    parser.add_argument("--planner-url", required=True)
    parser.add_argument("--cv-intent", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--previous", type=Path)
    parser.add_argument("--expected-evaluator", default="evaluator-cv")
    parser.add_argument("--timeout", type=float, default=1800)
    args = parser.parse_args()
    args.planner_url = args.planner_url.rstrip("/")
    url = urlsplit(args.planner_url)
    if url.scheme != "http" or url.hostname not in {"127.0.0.1", "localhost"} or not url.port or url.port == 7200 or url.path or url.username or url.password or url.query or url.fragment:
        parser.error("Use an explicitly isolated loopback planner port, not the walkthrough's default 7200")
    rehearsal = Rehearsal(args)
    try:
        getattr(rehearsal, args.stage.replace("-", "_"))()
        rehearsal.report["passed"] = True
    except Exception as exc:
        rehearsal.report["passed"] = False
        rehearsal.report["error"] = {"type": type(exc).__name__, "detail": str(exc)}
        raise
    finally:
        rehearsal.report["finished_at"] = now()
        rehearsal.save()
        print(json.dumps({"evidence": str(rehearsal.path), "passed": rehearsal.report.get("passed"),
                          "selected_evaluator": rehearsal.report.get("selected_evaluator"),
                          "checks": len(rehearsal.report["checks"])}), flush=True)


if __name__ == "__main__":
    main()
