# Session 4: control checks and draft quality

Reviewed on 25 October 2026. **All 110 automated control checks passed. The three generated CV assessments still contain material evidence-handling errors and inconsistent judgements.** The control result must not be presented as a quality score for the model or its recommendations.

## What the control checks establish

| Stage | Checks passed | Evidence |
|---|---:|---|
| Card evidence and rejection before application work | 20 | [Before](governance-before.json) |
| Updated declaration, cited eligibility and held draft | 27 | [Hold](governance-hold.json) |
| Restart recovery, exact release, repeated/conflicting review, quarantine and flow audit | 50 | [Review](governance-review.json) |
| Missing required wiki evidence prevents application work | 13 | [Missing evidence](governance-missing-evidence.json) |

The tests exercised actual AGNTCY discovery, wiki retrieval, course services, persistent case storage and hosted CV generation. Session 4 used the general CV evaluator; there was no decision-model allocation call. Card evidence, eligibility and flow audit are deterministic. The checks establish the recorded control sequence, digest/payload identity and error handling. Automated approval in the protocol test was deliberately synthetic; it was not an endorsement of the draft's employment recommendation. The actual planner restart and the subsequent browser review are recorded separately by the operator.

## Inputs and source boundaries

The three drafts used the same synthetic [Jordan Okafor CV](../checkout/system/inbox/s4-cv.txt) and [Senior Data Engineer — Healthcare Payments job description](../checkout/system/inbox/s4-jd.txt). The third run uploaded those files through Studio. Its stored upload bytes match the original fixtures exactly, and its trace contains the actual uploaded JD as selection context. The first two runs shared the same API intent. Session 4's fixed workflow and single eligible evaluator mean this is not a comparison of different AU allocations.

The source evidence establishes:

- The CV profile explicitly includes ownership of the **on-call rota** (lines 5–8).
- The CV states seven years across **fintech and e-commerce**. It does not separately establish five or more years of regulated financial-services work, or specific audit/compliance duties.
- The CV records mentoring two junior engineers and running office hours. It does not explicitly document responsibility for leading a team through delivery.
- The JD requires regulated-environment experience, team-delivery leadership and comfort with on-call work (lines 25–32).
- Direct NHS/healthcare data experience and practical GDPR/DPA experience are **nice-to-have**, not essential requirements (lines 34–36).

Fixture SHA-256 values:

```text
CV  2bc3c84123988c5ae2f07160a31759fdf668d899825b763811a5e79244fed336
JD  9fcb2b6d9165fca826118f939451923f70f36e9d98dc5c2588be14369a3fe77c
```

## Findings by draft

| Draft | Assessment / report | Main content finding |
|---|---|---|
| `caba4790114e` | `weak` / `pass` | The parser lost on-call evidence; the evaluator inflated a nice-to-have into an essential requirement; the reporter asserted absence of regulated experience. |
| `27bd118d1af8` | `fit` / `interview` | The parser retained on-call evidence, but the assessment omitted the explicit team-leadership evidence gap while scoring seniority 5. |
| `69cd2fffde68` | `fit` / `interview` | The evaluator and reporter asserted five-plus years of regulated fintech experience without source support. The report also blurred essential and desirable requirements. |

### First draft: evidence loss changes the judgement

Source: [held draft and complete AU responses](governance-hold.json), `runs.cv_held`.

The parser's one-line summary omitted the source profile's explicit on-call statement. The evaluator then described personal on-call duty as only implied by mentoring others. That reasoning is understandable from the reduced parser output, but is wrong against the actual CV: the information was lost at an earlier boundary.

The evaluator's rationale described healthcare data experience as essential. The JD places direct healthcare/NHS experience under nice-to-have. This raises the hiring bar beyond the supplied requirement.

The reporter's headline stated that the candidate had no regulated-environment experience and advised that an interview would add no value. The CV's fintech background is insufficient to prove the required regulated/audit experience, but it also does not justify categorical absence. The appropriate evidence status is unverified, rather than either established competence or established absence.

### Second draft: a different recommendation, with another gap omitted

Source: [review-stage evidence](governance-review.json), `runs.cv_for_quarantine`.

This parser summary retained on-call ownership. The evaluator consequently recognised on-call experience and returned `fit`; the reporter recommended interview. The evaluation correctly treated practical GDPR/DPA experience as nice-to-have.

However, the evaluator gave seniority a score of 5 without preserving the JD's essential team-leadership evidence gap. Senior titles and mentoring support an assessment of senior experience; they do not by themselves establish a track record of leading a team through delivery. This is a review concern, not a claim that one particular numerical score is objectively mandatory.

This separate case was deliberately quarantined by the automated protocol test. That action tested the rejection path; it does not itself establish a human judgement about the candidate.

### Third draft: uploaded files are correct, but a positive claim is unsupported

Source: [Studio multipart-upload result and trace](studio-upload-held.json).

The parser preserved the on-call statement and the work-history dates. The evaluator then asserted five-plus years of production data-pipeline work in fintech as a regulated financial-services environment, and said the core experience criterion was satisfied. The reporter repeated the duration and the regulated-work claim. Neither the original CV nor the parsed output establishes that combined claim. Total years across mixed sectors cannot automatically be counted as years of evidenced regulated work.

The evaluator did recognise the difference between mentoring and formal team leadership. The report nevertheless described the absence of healthcare/NHS background together with compliance work as something the role requires, obscuring the JD's essential/nice-to-have distinction.

The held upload record is the content evidence reviewed here. The operator subsequently rejected this exact draft through Studio with notes about the unsupported regulated-experience claim and the healthcare requirement framing; browser review evidence is stored separately.

## Interpretation for the course

These runs demonstrate why the review must inspect the **actual output against the source CV and JD**, rather than merely check a green card, valid JSON, model probability or successful workflow. The trace also helps locate the fault: a lost source fact at the parser, an unjustified requirement at the evaluator, and a stronger unsupported claim at the reporter are different problems.

The observed change from `weak/pass` to `fit/interview` is material, but three runs are not a reliability benchmark or an estimate of error frequency. These findings do not justify changing prompts to force one preferred verdict. They establish concrete items for a later quality review: preserve decision-relevant source facts, retain requirement priority, distinguish absence from missing evidence, and prevent reports from strengthening unsupported assessment claims.

No prompts, model settings or runtime code were changed during this quality review. The regulation corpus and control checks are teaching evidence; passing them does not establish legal compliance or effective human oversight.
